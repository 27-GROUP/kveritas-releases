# kveritas-notebook

K-Veritas notebook extension for Jupyter, Google Colab, and Kaggle.

Full parity with the K-Veritas Go CLI: init, run, phase, metric, claim, seed, seal.

## Install

```bash
pip install kveritas-notebook
```

## Quick Start

```python
import kveritas_notebook as kv

# Initialize session (optionally link to a class)
session = kv.init(class_code="CS229-ABC1", email="student@stanford.edu")

# Run your experiment
with session.run("training") as run:
    run.phase("data_loading")
    # ... load data ...

    run.phase("training")
    model.fit(X_train, y_train)

    run.phase("evaluation")
    accuracy = model.score(X_test, y_test)

    # Log metrics (equivalent to KVERITAS_METRIC)
    run.metric("accuracy", accuracy)
    run.metric("f1_score", f1)

    # Declare claims (equivalent to KVERITAS_CLAIM)
    run.claim("accuracy", ">=", 0.90)

    # Commit seeds (equivalent to KVERITAS_INPUT)
    run.seed("random", 42)

# Seal and download signed PDF
report = session.seal()
report.download()  # In Colab, triggers browser download
```

## Simple Mode (no run context)

```python
import kveritas_notebook as kv

session = kv.init()

# Log directly on the session
session.log_metric("accuracy", 0.95)
session.log_metric("loss", 0.042)
session.log_phase("training")
session.log_claim("accuracy", ">=", 0.90)
session.log_seed("random", 42)

report = session.seal()
report.download()
```

## Features

- Hardware detection: CPU model, GPU names/count, memory, OS
- Phase boundaries with hardware counter snapshots
- Inline claims and seed commitments
- Cryptographic signing via the K-Veritas attestation server
- Class enrollment via class codes (for academic use)
- Works in Jupyter, JupyterLab, Google Colab, Kaggle
