"""Session management. Mirrors the Go CLI's init / run / seal lifecycle."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Generator

import requests

from kveritas_notebook.hardware import detect as detect_hardware, snapshot_counters

_DEFAULT_SERVER = "https://kveritas-api-production.up.railway.app"


def init(
    class_code: str = "",
    email: str = "",
    server: str = "",
) -> Session:
    """Initialize a K-Veritas session.

    Args:
        class_code: Optional class enrollment code (links report to class).
        email: Optional user email for class association.
        server: Attestation server URL. Defaults to hosted server.

    Returns:
        A Session object for recording runs.
    """
    server_url = server or os.getenv("KVERITAS_SERVER", _DEFAULT_SERVER)
    session = Session(server_url=server_url, class_code=class_code, email=email)
    session._register()
    return session


class RunContext:
    """Context for a single experiment run. Captures metrics, phases, claims, seeds."""

    def __init__(self, command: str = "") -> None:
        self.command = command
        self.metrics: list[dict[str, Any]] = []
        self.phases: list[dict[str, Any]] = []
        self.claims: list[dict[str, Any]] = []
        self.seeds: list[dict[str, Any]] = []
        self.start_time: float = 0
        self.end_time: float = 0
        self.exit_code: int = 0
        self._hardware = detect_hardware()

    def metric(self, name: str, value: float, step: str = "") -> None:
        """Log a metric. Equivalent to KVERITAS_METRIC."""
        self.metrics.append({
            "name": name,
            "value": value,
            "step": step,
            "source": "explicit",
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    def phase(self, name: str) -> None:
        """Mark a phase boundary. Equivalent to KVERITAS_PHASE.

        Captures hardware counters at each boundary.
        """
        counters = snapshot_counters()
        self.phases.append({
            "name": name,
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "counters": counters,
        })

    def claim(self, metric_name: str, operator: str, value: float) -> None:
        """Declare an inline claim. Equivalent to KVERITAS_CLAIM."""
        self.claims.append({
            "metric": metric_name,
            "operator": operator,
            "value": value,
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    def seed(self, source: str, value: Any) -> None:
        """Declare a seed commitment. Equivalent to KVERITAS_INPUT."""
        self.seeds.append({
            "source": source,
            "value": str(value),
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    def auto_detect_metrics(self) -> None:
        """Try to auto-detect metrics from common ML frameworks."""
        # Keras / TensorFlow
        try:
            import tensorflow as tf
            for var_name, obj in _get_caller_locals().items():
                if hasattr(obj, "history") and hasattr(obj.history, "history"):
                    history = obj.history.history
                    for metric_name, values in history.items():
                        if values:
                            self.metric(metric_name, float(values[-1]))
        except ImportError:
            pass

        # scikit-learn
        try:
            for var_name, obj in _get_caller_locals().items():
                if hasattr(obj, "best_score_"):
                    self.metric("best_score", float(obj.best_score_))
                if hasattr(obj, "cv_results_") and "mean_test_score" in getattr(obj, "cv_results_", {}):
                    scores = obj.cv_results_["mean_test_score"]
                    if len(scores) > 0:
                        self.metric("best_cv_score", float(max(scores)))
        except Exception:
            pass

    def _to_dict(self) -> dict[str, Any]:
        duration_sec = self.end_time - self.start_time if self.end_time else 0
        return {
            "command": self.command,
            "duration_sec": round(duration_sec, 3),
            "duration_fmt": f"{duration_sec:.1f}s",
            "exit_code": self.exit_code,
            "metrics": self.metrics,
            "phases": self.phases,
            "claims": self.claims,
            "seeds": self.seeds,
            "hardware": self._hardware,
            "hardware_samples": [
                {"counters": p.get("counters", {})} for p in self.phases
            ],
            "metric_hash": hashlib.sha256(
                json.dumps(self.metrics, sort_keys=True).encode()
            ).hexdigest(),
        }


class SealResult:
    """Result of sealing a session. Contains the signed PDF and bundle."""

    def __init__(
        self,
        data: dict[str, Any],
        pdf_bytes: bytes,
        bundle_path: str,
        bundle_hash: str,
    ) -> None:
        self.data = data
        self.signature = data.get("signature", "")
        self.data_hash = data.get("data_hash", "")
        self.signed_at = data.get("signed_at", "")
        self.nonce = data.get("nonce", "")
        self._pdf_bytes = pdf_bytes
        self.bundle_path = bundle_path
        self.bundle_hash = bundle_hash

    def download(self, path: str = "kveritas_report.pdf") -> str:
        """Save the signed PDF report.

        In Colab, triggers a browser download for both the PDF and bundle.
        """
        with open(path, "wb") as f:
            f.write(self._pdf_bytes)

        print(f"Report saved: {path} ({len(self._pdf_bytes)} bytes)")
        print(f"Bundle saved: {self.bundle_path}")

        # Try Colab download
        try:
            from google.colab import files
            files.download(path)
            files.download(self.bundle_path)
        except (ImportError, Exception):
            pass

        return path

    @property
    def url(self) -> str:
        return "https://kveritas.org/verify"


class Session:
    """A K-Veritas session. Manages one or more experiment runs."""

    def __init__(self, server_url: str, class_code: str = "", email: str = "") -> None:
        self.server_url = server_url.rstrip("/")
        self.class_code = class_code
        self.email = email
        self.session_id = str(uuid.uuid4())
        self.machine_id = hashlib.sha256(
            f"{platform.node()}{platform.machine()}{os.getuid() if hasattr(os, 'getuid') else ''}".encode()
        ).hexdigest()[:16]
        self.token = ""
        self.runs: list[RunContext] = []
        self._sealed = False
        self._implicit_run: RunContext | None = None

    def _register(self) -> None:
        """Register session with the attestation server (equivalent to kveritas init)."""
        try:
            resp = requests.post(
                f"{self.server_url}/api/v1/init",
                json={
                    "session_id": self.session_id,
                    "machine_id": self.machine_id,
                    "init_at": datetime.now(timezone.utc).isoformat(),
                    "class_code": self.class_code,
                },
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                self.token = data.get("token", "")
        except requests.RequestException:
            pass

    @contextmanager
    def run(self, command: str = "") -> Generator[RunContext, None, None]:
        """Start a new experiment run.

        Usage:
            with session.run("python train.py") as run:
                run.phase("training")
                model.fit(...)
                run.metric("accuracy", 0.95)
        """
        # Close any open implicit run before starting an explicit one
        self._close_implicit_run()

        ctx = RunContext(command=command)
        ctx.start_time = time.time()
        try:
            yield ctx
        except Exception:
            ctx.exit_code = 1
            raise
        finally:
            ctx.end_time = time.time()
            if ctx.exit_code == 0:
                self.runs.append(ctx)

    def _get_implicit_run(self) -> RunContext:
        """Get or create the current implicit run for loose logging."""
        if self._implicit_run is None:
            self._implicit_run = RunContext(command="notebook")
            self._implicit_run.start_time = time.time()
            self.runs.append(self._implicit_run)
        return self._implicit_run

    def _close_implicit_run(self) -> None:
        """Close the current implicit run so the next log_* starts a fresh one."""
        if self._implicit_run is not None:
            if self._implicit_run.end_time == 0:
                self._implicit_run.end_time = time.time()
            self._implicit_run = None

    def log_metric(self, name: str, value: float, step: str = "") -> None:
        """Log a metric outside of a run context.

        Accumulates into an implicit run. Multiple log_* calls across
        notebook cells share the same implicit run until an explicit
        session.run() context is opened.
        """
        self._get_implicit_run().metric(name, value, step)

    def log_phase(self, name: str) -> None:
        """Log a phase outside of a run context."""
        self._get_implicit_run().phase(name)

    def log_claim(self, metric_name: str, operator: str, value: float) -> None:
        """Log a claim outside of a run context."""
        self._get_implicit_run().claim(metric_name, operator, value)

    def log_seed(self, source: str, value: Any) -> None:
        """Log a seed outside of a run context."""
        self._get_implicit_run().seed(source, value)

    def seal(self, output: str = "kveritas_report.pdf", bundle_output: str = "bundle.zip") -> SealResult:
        """Seal the session: sign, generate PDF report, and create source bundle.

        Equivalent to `kveritas seal --output report.pdf`. Produces:
        - A signed PDF with embedded experiment data and cryptographic proof
        - A bundle.zip containing the notebook/script source code

        Args:
            output: Path for the PDF report.
            bundle_output: Path for the source bundle ZIP.
        """
        from kveritas_notebook.report import generate_pdf, create_bundle, bundle_hash as compute_bundle_hash

        if self._sealed:
            raise RuntimeError("Session already sealed")

        # Close any open implicit run
        self._close_implicit_run()

        # Finalize any open runs
        for run in self.runs:
            if run.end_time == 0:
                run.end_time = time.time()

        # Create source bundle first (so we can include its hash in the report)
        bundle_path = create_bundle(bundle_output)
        b_hash = compute_bundle_hash(bundle_path)

        # Build the report data (same structure as Go CLI)
        report_data = {
            "session_id": self.session_id,
            "machine_id": self.machine_id,
            "source_bundle_hash": b_hash,
            "runs": [r._to_dict() for r in self.runs],
        }

        # Canonical hash
        canonical = json.dumps(report_data, sort_keys=True, separators=(",", ":"))
        data_hash = hashlib.sha256(canonical.encode()).hexdigest()

        total_metrics = sum(len(r.metrics) for r in self.runs)

        # Sign via server
        try:
            resp = requests.post(
                f"{self.server_url}/api/v1/notebook-seal",
                json={
                    "data_hash": data_hash,
                    "session_id": self.session_id,
                    "machine_id": self.machine_id,
                    "class_code": self.class_code,
                    "user_email": self.email,
                    "run_count": len(self.runs),
                    "metric_count": total_metrics,
                },
                timeout=30,
            )
            if resp.status_code != 200:
                raise RuntimeError(f"Seal failed: {resp.status_code} {resp.text}")

            result = resp.json()
        except requests.RequestException as e:
            raise RuntimeError(f"Could not connect to attestation server: {e}")

        # Generate signed PDF report
        pdf_bytes = generate_pdf(
            report_data=report_data,
            signature=result["signature"],
            data_hash=data_hash,
            nonce=result["nonce"],
            signed_at=result["signed_at"],
            signed_message_hash=result.get("signed_message_hash", ""),
        )

        self._sealed = True
        result["data_hash"] = data_hash

        return SealResult(
            data=result,
            pdf_bytes=pdf_bytes,
            bundle_path=bundle_path,
            bundle_hash=b_hash,
        )

    def status(self) -> dict[str, Any]:
        """Return current session status."""
        return {
            "session_id": self.session_id,
            "machine_id": self.machine_id,
            "runs": len(self.runs),
            "total_metrics": sum(len(r.metrics) for r in self.runs),
            "total_phases": sum(len(r.phases) for r in self.runs),
            "total_claims": sum(len(r.claims) for r in self.runs),
            "total_seeds": sum(len(r.seeds) for r in self.runs),
            "sealed": self._sealed,
        }


def _get_caller_locals() -> dict:
    """Try to get the caller's local variables for auto-detection."""
    import inspect
    frame = inspect.currentframe()
    try:
        if frame and frame.f_back and frame.f_back.f_back:
            return frame.f_back.f_back.f_locals
    except Exception:
        pass
    finally:
        del frame
    return {}
