"""PDF report generation and source bundle creation for notebook extension.

Generates a signed PDF report with embedded experiment data (same format
as the Go CLI) and a bundle.zip containing the notebook source.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def generate_pdf(
    report_data: dict[str, Any],
    signature: str,
    data_hash: str,
    nonce: str,
    signed_at: str,
    signed_message_hash: str,
) -> bytes:
    """Generate a signed K-Veritas PDF report with embedded data.

    Returns the PDF as bytes.
    """
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.lib.enums import TA_LEFT, TA_CENTER
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable,
    )

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter, topMargin=0.6 * inch, bottomMargin=0.6 * inch)
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle("KVTitle", parent=styles["Title"], fontSize=18, spaceAfter=4)
    subtitle_style = ParagraphStyle("KVSub", parent=styles["Normal"], fontSize=9, textColor=colors.grey, spaceAfter=12)
    heading_style = ParagraphStyle("KVH2", parent=styles["Heading2"], fontSize=12, spaceBefore=14, spaceAfter=6)
    normal_style = ParagraphStyle("KVNormal", parent=styles["Normal"], fontSize=9, leading=13)
    mono_style = ParagraphStyle("KVMono", parent=styles["Code"], fontSize=8, leading=11, fontName="Courier")
    footer_style = ParagraphStyle("KVFoot", parent=styles["Normal"], fontSize=7, textColor=colors.grey, alignment=TA_CENTER)

    story = []

    # Title
    story.append(Paragraph("K-Veritas Verification Report", title_style))
    session_id = report_data.get("session_id", "")
    machine_id = report_data.get("machine_id", "")
    story.append(Paragraph(f"Session: {session_id} | Machine: {machine_id}", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.Color(0.85, 0.85, 0.85)))
    story.append(Spacer(1, 10))

    # Signature block
    story.append(Paragraph("Cryptographic Signature", heading_style))
    sig_data = [
        ["Data Hash", data_hash],
        ["Nonce", nonce],
        ["Signed At", signed_at],
        ["Message Hash", signed_message_hash],
        ["Signature", signature[:64] + "..."],
    ]
    sig_table = Table(sig_data, colWidths=[1.4 * inch, 5.0 * inch])
    sig_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (1, 0), (1, -1), "Courier"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.Color(0.3, 0.3, 0.3)),
    ]))
    story.append(sig_table)
    story.append(Spacer(1, 10))

    # Runs
    runs = report_data.get("runs", [])
    if runs:
        story.append(Paragraph(f"Experiment Runs ({len(runs)})", heading_style))
        for i, run in enumerate(runs):
            story.append(Paragraph(f"<b>Run {i+1}</b> - {run.get('command', 'notebook')} ({run.get('duration_fmt', '')})", normal_style))

            # Metrics
            metrics = run.get("metrics", [])
            if metrics:
                metric_data = [["Metric", "Value", "Source"]]
                for m in metrics:
                    val = m.get("value", "")
                    if isinstance(val, float):
                        val = f"{val:.6f}" if val < 1 else f"{val:.4f}"
                    metric_data.append([m.get("name", ""), str(val), m.get("source", "")])
                mt = Table(metric_data, colWidths=[2.0 * inch, 2.0 * inch, 1.5 * inch])
                mt.setStyle(TableStyle([
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.Color(0.95, 0.95, 0.95)),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.Color(0.9, 0.9, 0.9)),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                    ("TOPPADDING", (0, 0), (-1, -1), 3),
                ]))
                story.append(mt)

            # Phases
            phases = run.get("phases", [])
            if phases:
                story.append(Spacer(1, 4))
                phase_names = ", ".join(p.get("name", "") for p in phases)
                story.append(Paragraph(f"<i>Phases: {phase_names}</i>", normal_style))

            # Claims
            claims = run.get("claims", [])
            if claims:
                claim_strs = ", ".join(f"{c['metric']} {c['operator']} {c['value']}" for c in claims)
                story.append(Paragraph(f"<i>Claims: {claim_strs}</i>", normal_style))

            # Seeds
            seeds = run.get("seeds", [])
            if seeds:
                seed_strs = ", ".join(f"{s['source']}={s['value']}" for s in seeds)
                story.append(Paragraph(f"<i>Seeds: {seed_strs}</i>", normal_style))

            story.append(Spacer(1, 8))

    # Hardware
    if runs:
        hw = runs[0].get("hardware", {})
        if hw:
            story.append(Paragraph("Hardware Environment", heading_style))
            hw_rows = []
            if hw.get("cpu_model"):
                hw_rows.append(["CPU", hw["cpu_model"]])
            if hw.get("cpu_cores"):
                hw_rows.append(["Cores", str(hw["cpu_cores"])])
            if hw.get("mem_gb"):
                hw_rows.append(["Memory", f"{hw['mem_gb']} GB"])
            if hw.get("gpu_names"):
                gpu_str = f"{hw.get('gpu_count', len(hw['gpu_names']))}x {hw['gpu_names'][0]}"
                hw_rows.append(["GPU", gpu_str])
            elif hw.get("gpu_info"):
                hw_rows.append(["GPU", hw["gpu_info"]])
            if hw.get("os"):
                hw_rows.append(["OS / Arch", f"{hw['os']} / {hw.get('arch', '')}"])
            if hw_rows:
                ht = Table(hw_rows, colWidths=[1.4 * inch, 5.0 * inch])
                ht.setStyle(TableStyle([
                    ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                    ("TEXTCOLOR", (0, 0), (0, -1), colors.Color(0.3, 0.3, 0.3)),
                ]))
                story.append(ht)

    # Footer
    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.Color(0.85, 0.85, 0.85)))
    story.append(Spacer(1, 6))
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    story.append(Paragraph(
        f"Generated by K-Veritas Notebook Extension v0.1.0 | {now}",
        footer_style,
    ))

    doc.build(story)
    visual_pdf = buf.getvalue()

    # Embed data + signature using pypdf
    return _embed_data(
        visual_pdf, report_data, signature,
        data_hash, nonce, signed_at, signed_message_hash,
    )


def _embed_data(
    pdf_bytes: bytes,
    report_data: dict,
    signature: str,
    data_hash: str,
    nonce: str,
    signed_at: str,
    signed_message_hash: str,
) -> bytes:
    """Embed experiment JSON and signature into the PDF, matching Go CLI format."""
    from pypdf import PdfReader, PdfWriter

    reader = PdfReader(io.BytesIO(pdf_bytes))
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)

    report_json = json.dumps(report_data, sort_keys=True, separators=(",", ":"))
    writer.add_attachment("experiment_data.json", report_json.encode("utf-8"))
    writer.add_attachment("signature.sig", signature.encode("utf-8"))

    writer.add_metadata({
        "/VeritasVersion": "0.1.0-notebook",
        "/VeritasDataHash": data_hash,
        "/VeritasNonce": nonce,
        "/VeritasSignedAt": signed_at,
        "/VeritasSignedMessageHash": signed_message_hash,
        "/VeritasSigned": "true",
    })

    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


def create_bundle(output_path: str = "bundle.zip") -> str:
    """Create a source bundle ZIP of the current notebook/script.

    Detects:
    1. Running inside a Jupyter/Colab notebook -> bundles the .ipynb
    2. Running as a Python script -> bundles the script and local imports
    """
    buf = io.BytesIO()

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # Try to find the notebook file
        notebook_path = _find_notebook()
        if notebook_path and os.path.exists(notebook_path):
            zf.write(notebook_path, os.path.basename(notebook_path))
        else:
            # Bundle the calling script
            import inspect
            for frame_info in inspect.stack():
                src_file = frame_info.filename
                if src_file and not src_file.startswith("<") and os.path.exists(src_file):
                    basename = os.path.basename(src_file)
                    if basename.endswith(".py") and basename != "session.py":
                        zf.write(src_file, basename)

        # Also bundle any .py files in the working directory
        cwd = os.getcwd()
        for fname in os.listdir(cwd):
            if fname.endswith(".py") and os.path.isfile(os.path.join(cwd, fname)):
                full = os.path.join(cwd, fname)
                if full not in [info.filename for info in zf.infolist()]:
                    zf.write(full, fname)

    bundle_bytes = buf.getvalue()
    with open(output_path, "wb") as f:
        f.write(bundle_bytes)

    return output_path


def bundle_hash(path: str) -> str:
    """Compute SHA-256 hash of the bundle file."""
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _find_notebook() -> str | None:
    """Try to find the current Jupyter/Colab notebook file path."""
    # Method 1: ipynbname (if installed)
    try:
        import ipynbname
        return str(ipynbname.path())
    except (ImportError, Exception):
        pass

    # Method 2: Colab
    try:
        from google.colab import _message
        notebook_path = _message.blocking_request("get_ipynb")
        if notebook_path:
            return None  # Colab doesn't give a file path, handled differently
    except (ImportError, Exception):
        pass

    # Method 3: Check common locations
    cwd = os.getcwd()
    for fname in os.listdir(cwd):
        if fname.endswith(".ipynb"):
            return os.path.join(cwd, fname)

    return None
