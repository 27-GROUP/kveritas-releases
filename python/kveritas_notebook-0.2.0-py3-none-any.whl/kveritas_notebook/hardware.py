"""Hardware detection module. Mirrors the Go CLI's hardware.Snapshot()."""

from __future__ import annotations

import os
import platform
import subprocess
from typing import Any


def detect() -> dict[str, Any]:
    """Detect hardware environment. Works on Linux, macOS, Windows, Colab, Kaggle."""
    info: dict[str, Any] = {
        "os": platform.system(),
        "arch": platform.machine(),
        "cpu_model": _cpu_model(),
        "cpu_cores": os.cpu_count() or 0,
        "mem_gb": _mem_gb(),
        "gpu_count": 0,
        "gpu_names": [],
        "gpu_info": "",
    }

    gpus = _detect_gpus()
    if gpus:
        info["gpu_count"] = len(gpus)
        info["gpu_names"] = gpus
        if len(set(gpus)) == 1:
            info["gpu_info"] = f"{len(gpus)}x {gpus[0]}"
        else:
            info["gpu_info"] = ", ".join(gpus)

    return info


def snapshot_counters() -> dict[str, Any]:
    """Capture current hardware counters for phase boundaries."""
    counters: dict[str, Any] = {}

    try:
        import resource
        usage = resource.getrusage(resource.RUSAGE_SELF)
        counters["cpu_time_sec"] = round(usage.ru_utime + usage.ru_stime, 3)
        counters["mem_used_mb"] = round(usage.ru_maxrss / 1024, 1) if platform.system() == "Linux" else round(usage.ru_maxrss / (1024 * 1024), 1)
    except (ImportError, AttributeError):
        pass

    gpu_util, gpu_mem = _gpu_counters()
    if gpu_util is not None:
        counters["gpu_util_pct"] = gpu_util
    if gpu_mem is not None:
        counters["gpu_mem_mb"] = gpu_mem

    return counters


def _cpu_model() -> str:
    try:
        if platform.system() == "Linux":
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        return line.split(":", 1)[1].strip()
        elif platform.system() == "Darwin":
            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
    except Exception:
        pass
    return platform.processor() or "unknown"


def _mem_gb() -> float:
    try:
        if platform.system() == "Linux":
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal"):
                        kb = int(line.split()[1])
                        return round(kb / (1024 * 1024), 1)
        elif platform.system() == "Darwin":
            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return round(int(result.stdout.strip()) / (1024 ** 3), 1)
    except Exception:
        pass
    return 0.0


def _detect_gpus() -> list[str]:
    # Try PyTorch first
    try:
        import torch
        if torch.cuda.is_available():
            return [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
    except ImportError:
        pass

    # Try nvidia-smi
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return [line.strip() for line in result.stdout.strip().split("\n") if line.strip()]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return []


def _gpu_counters() -> tuple[float | None, float | None]:
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            parts = result.stdout.strip().split("\n")[0].split(",")
            if len(parts) >= 2:
                return float(parts[0].strip()), float(parts[1].strip())
    except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
        pass
    return None, None
