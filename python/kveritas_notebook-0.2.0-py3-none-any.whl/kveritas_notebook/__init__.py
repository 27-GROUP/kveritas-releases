"""K-Veritas notebook extension.

Full parity with the K-Veritas Go CLI for Jupyter, Colab, and Kaggle.

Usage:
    import kveritas_notebook as kv

    session = kv.init(class_code="CS229-ABC1")

    with session.run("python train.py") as run:
        run.phase("training")
        # ... training code ...
        run.metric("accuracy", 0.95)
        run.claim("accuracy", ">=", 0.90)
        run.seed("random", 42)

    report = session.seal()
    report.download()
"""

from kveritas_notebook.session import Session, init

__all__ = ["Session", "init"]
__version__ = "0.2.0"
