"""K-Veritas notebook helper.

Thin wrapper around the K-Veritas Go CLI for Jupyter, Colab, and Kaggle.
Requires the kveritas binary to be installed (see kveritas.org/download).

Usage:
    import kveritas_notebook as kv

    kv.init()
    kv.start_run("training experiment")
    kv.phase("training")
    # ... training code ...
    kv.metric("accuracy", 0.95)
    kv.claim("accuracy", ">=", 0.90)
    kv.seed("random", 42)
    kv.end_run()
    kv.seal()
"""

import subprocess
import shutil
import os
import sys

__version__ = "0.3.0"

_BIN = None


def _find_binary() -> str:
    global _BIN
    if _BIN:
        return _BIN
    path = shutil.which("kveritas")
    if path:
        _BIN = path
        return _BIN
    raise FileNotFoundError(
        "kveritas binary not found. Install it from https://kveritas.org/download"
    )


def _run_cmd(*args: str, check: bool = True) -> str:
    binary = _find_binary()
    result = subprocess.run(
        [binary] + list(args),
        capture_output=True, text=True, timeout=60,
    )
    output = result.stdout.strip()
    if result.returncode != 0 and check:
        err = result.stderr.strip() or output
        raise RuntimeError(f"kveritas {args[0]}: {err}")
    if output:
        print(output)
    return output


def init(server: str = "", local: bool = False) -> str:
    """Initialize a K-Veritas session. Returns the session ID."""
    args = ["init"]
    if server:
        args += ["--server", server]
    if local:
        args.append("--local")
    return _run_cmd(*args)


def start_run(command: str = "") -> str:
    """Start a new notebook run."""
    args = ["start-run"]
    if command:
        args += ["--command", command]
    return _run_cmd(*args)


def end_run() -> str:
    """End the current notebook run."""
    return _run_cmd("end-run")


def metric(name: str, value: float, step: str = "") -> str:
    """Log a metric."""
    args = ["log", "metric", name, str(value)]
    if step:
        args.append(step)
    return _run_cmd(*args)


def phase(name: str) -> str:
    """Log a phase boundary with hardware counters."""
    return _run_cmd("log", "phase", name)


def claim(metric_name: str, operator: str, value: float) -> str:
    """Declare a claim."""
    return _run_cmd("log", "claim", metric_name, operator, str(value))


def seed(source: str, value) -> str:
    """Declare a seed."""
    return _run_cmd("log", "seed", source, str(value))


def seal(output: str = "kveritas_report.pdf", local_key: str = "") -> str:
    """Seal the session and generate a signed PDF report."""
    args = ["seal", "--output", output]
    if local_key:
        args += ["--local-key", local_key]
    return _run_cmd(*args)


def status() -> str:
    """Show session status."""
    return _run_cmd("status")


def verify(pdf_path: str) -> str:
    """Verify a K-Veritas report."""
    return _run_cmd("verify", pdf_path)


def clean() -> str:
    """Remove the .kveritas session directory."""
    return _run_cmd("clean")


def install(platform: str = "") -> None:
    """Download and install the kveritas binary.

    Works in Colab/Kaggle where the binary isn't pre-installed.
    """
    import platform as plat
    base = "https://github.com/27-GROUP/kveritas-releases/raw/main/bin"

    system = plat.system().lower()
    machine = plat.machine().lower()

    if "x86_64" in machine or "amd64" in machine:
        arch = "amd64"
    elif "arm" in machine or "aarch64" in machine:
        arch = "arm64"
    else:
        arch = "amd64"

    if system == "darwin":
        fname = f"kveritas-darwin-{arch}"
    elif system == "windows":
        fname = f"kveritas-windows-{arch}.exe"
    else:
        fname = f"kveritas-linux-{arch}"

    url = f"{base}/{fname}"
    dest = "/usr/local/bin/kveritas"

    print(f"Downloading {fname}...")
    subprocess.run(
        ["curl", "-fsSL", url, "-o", dest],
        check=True, timeout=30,
    )
    subprocess.run(["chmod", "+x", dest], check=True)
    print(f"Installed: {dest}")

    global _BIN
    _BIN = dest
