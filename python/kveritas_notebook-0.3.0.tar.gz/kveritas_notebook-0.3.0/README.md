# kveritas-notebook

Thin Python wrapper around the K-Veritas Go CLI for Jupyter, Colab, and Kaggle.

Zero dependencies. Calls the `kveritas` binary directly.

## Install

```bash
pip install kveritas-notebook
```

The Go CLI binary must also be installed. In Colab/Kaggle:

```python
import kveritas_notebook as kv
kv.install()  # downloads and installs the binary automatically
```

## Usage

```python
import kveritas_notebook as kv

kv.install()  # only needed once per runtime (Colab/Kaggle)
kv.init()

kv.start_run("cifar10 training")
kv.seed("torch", 42)
kv.phase("data_loading")
# ... load data ...
kv.phase("training")
# ... train model ...
kv.metric("accuracy", 0.95)
kv.metric("loss", 0.042)
kv.claim("accuracy", ">=", 0.90)
kv.phase("evaluation")
# ... evaluate ...
kv.metric("test_accuracy", 0.93)
kv.end_run()

kv.seal()  # produces kveritas_report.pdf
```

## Multiple Runs

```python
kv.start_run("baseline")
kv.metric("accuracy", 0.82)
kv.end_run()

kv.start_run("improved")
kv.metric("accuracy", 0.91)
kv.end_run()

kv.seal()  # report contains both runs
```
