"""Session management. Mirrors the Go CLI's init / run / seal lifecycle."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Generator

import requests

from kveritas_notebook.hardware import detect as detect_hardware, snapshot_counters

_DEFAULT_SERVER = "https://kveritas-api-production.up.railway.app"


def init(
    class_code: str = "",
    email: str = "",
    server: str = "",
) -> Session:
    """Initialize a K-Veritas session.

    Args:
        class_code: Optional class enrollment code (links report to class).
        email: Optional user email for class association.
        server: Attestation server URL. Defaults to hosted server.

    Returns:
        A Session object for recording runs.
    """
    server_url = server or os.getenv("KVERITAS_SERVER", _DEFAULT_SERVER)
    session = Session(server_url=server_url, class_code=class_code, email=email)
    session._register()
    return session


class RunContext:
    """Context for a single experiment run. Captures metrics, phases, claims, seeds."""

    def __init__(self, command: str = "") -> None:
        self.command = command
        self.metrics: list[dict[str, Any]] = []
        self.phases: list[dict[str, Any]] = []
        self.claims: list[dict[str, Any]] = []
        self.seeds: list[dict[str, Any]] = []
        self.start_time: float = 0
        self.end_time: float = 0
        self.exit_code: int = 0
        self._hardware = detect_hardware()

    def metric(self, name: str, value: float, step: str = "") -> None:
        """Log a metric. Equivalent to KVERITAS_METRIC."""
        self.metrics.append({
            "name": name,
            "value": value,
            "step": step,
            "source": "explicit",
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    def phase(self, name: str) -> None:
        """Mark a phase boundary. Equivalent to KVERITAS_PHASE.

        Captures hardware counters at each boundary.
        """
        counters = snapshot_counters()
        self.phases.append({
            "name": name,
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "counters": counters,
        })

    def claim(self, metric_name: str, operator: str, value: float) -> None:
        """Declare an inline claim. Equivalent to KVERITAS_CLAIM."""
        self.claims.append({
            "metric": metric_name,
            "operator": operator,
            "value": value,
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    def seed(self, source: str, value: Any) -> None:
        """Declare a seed commitment. Equivalent to KVERITAS_INPUT."""
        self.seeds.append({
            "source": source,
            "value": str(value),
            "line": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    def auto_detect_metrics(self) -> None:
        """Try to auto-detect metrics from common ML frameworks."""
        # Keras / TensorFlow
        try:
            import tensorflow as tf
            for var_name, obj in _get_caller_locals().items():
                if hasattr(obj, "history") and hasattr(obj.history, "history"):
                    history = obj.history.history
                    for metric_name, values in history.items():
                        if values:
                            self.metric(metric_name, float(values[-1]))
        except ImportError:
            pass

        # scikit-learn
        try:
            for var_name, obj in _get_caller_locals().items():
                if hasattr(obj, "best_score_"):
                    self.metric("best_score", float(obj.best_score_))
                if hasattr(obj, "cv_results_") and "mean_test_score" in getattr(obj, "cv_results_", {}):
                    scores = obj.cv_results_["mean_test_score"]
                    if len(scores) > 0:
                        self.metric("best_cv_score", float(max(scores)))
        except Exception:
            pass

    def _to_dict(self) -> dict[str, Any]:
        duration_sec = self.end_time - self.start_time if self.end_time else 0
        return {
            "command": self.command,
            "duration_sec": round(duration_sec, 3),
            "duration_fmt": f"{duration_sec:.1f}s",
            "exit_code": self.exit_code,
            "metrics": self.metrics,
            "phases": self.phases,
            "claims": self.claims,
            "seeds": self.seeds,
            "hardware": self._hardware,
            "hardware_samples": [
                {"counters": p.get("counters", {})} for p in self.phases
            ],
            "metric_hash": hashlib.sha256(
                json.dumps(self.metrics, sort_keys=True).encode()
            ).hexdigest(),
        }


class SealResult:
    """Result of sealing a session. Contains the signed report data."""

    def __init__(self, data: dict[str, Any], pdf_bytes: bytes | None = None) -> None:
        self.data = data
        self.signature = data.get("signature", "")
        self.data_hash = data.get("data_hash", "")
        self.signed_at = data.get("signed_at", "")
        self.nonce = data.get("nonce", "")
        self._pdf_bytes = pdf_bytes

    def download(self, path: str = "kveritas_report.pdf") -> str:
        """Download the signed report PDF.

        In Colab, triggers a browser download.
        Otherwise saves to the given path.
        """
        if self._pdf_bytes:
            with open(path, "wb") as f:
                f.write(self._pdf_bytes)

            # Try Colab download
            try:
                from google.colab import files
                files.download(path)
            except (ImportError, Exception):
                pass

            return path

        return path

    @property
    def url(self) -> str:
        return f"https://kveritas.org/verify"


class Session:
    """A K-Veritas session. Manages one or more experiment runs."""

    def __init__(self, server_url: str, class_code: str = "", email: str = "") -> None:
        self.server_url = server_url.rstrip("/")
        self.class_code = class_code
        self.email = email
        self.session_id = str(uuid.uuid4())
        self.machine_id = hashlib.sha256(
            f"{platform.node()}{platform.machine()}{os.getuid() if hasattr(os, 'getuid') else ''}".encode()
        ).hexdigest()[:16]
        self.token = ""
        self.runs: list[RunContext] = []
        self._sealed = False

    def _register(self) -> None:
        """Register session with the attestation server (equivalent to kveritas init)."""
        try:
            resp = requests.post(
                f"{self.server_url}/api/v1/init",
                json={
                    "session_id": self.session_id,
                    "machine_id": self.machine_id,
                    "init_at": datetime.now(timezone.utc).isoformat(),
                    "class_code": self.class_code,
                },
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                self.token = data.get("token", "")
        except requests.RequestException:
            pass

    @contextmanager
    def run(self, command: str = "") -> Generator[RunContext, None, None]:
        """Start a new experiment run.

        Usage:
            with session.run("python train.py") as run:
                run.phase("training")
                model.fit(...)
                run.metric("accuracy", 0.95)
        """
        ctx = RunContext(command=command)
        ctx.start_time = time.time()
        try:
            yield ctx
        except Exception:
            ctx.exit_code = 1
            raise
        finally:
            ctx.end_time = time.time()
            if ctx.exit_code == 0:
                self.runs.append(ctx)

    def log_metric(self, name: str, value: float, step: str = "") -> None:
        """Log a metric outside of a run context.

        If no run is active, creates a default run.
        """
        if not self.runs:
            ctx = RunContext(command="notebook")
            ctx.start_time = time.time()
            self.runs.append(ctx)
        self.runs[-1].metric(name, value, step)

    def log_phase(self, name: str) -> None:
        """Log a phase outside of a run context."""
        if not self.runs:
            ctx = RunContext(command="notebook")
            ctx.start_time = time.time()
            self.runs.append(ctx)
        self.runs[-1].phase(name)

    def log_claim(self, metric_name: str, operator: str, value: float) -> None:
        """Log a claim outside of a run context."""
        if not self.runs:
            ctx = RunContext(command="notebook")
            ctx.start_time = time.time()
            self.runs.append(ctx)
        self.runs[-1].claim(metric_name, operator, value)

    def log_seed(self, source: str, value: Any) -> None:
        """Log a seed outside of a run context."""
        if not self.runs:
            ctx = RunContext(command="notebook")
            ctx.start_time = time.time()
            self.runs.append(ctx)
        self.runs[-1].seed(source, value)

    def seal(self) -> SealResult:
        """Seal the session and sign the report.

        Equivalent to kveritas seal. Sends all run data to the attestation
        server for signing.
        """
        if self._sealed:
            raise RuntimeError("Session already sealed")

        # Finalize any open runs
        for run in self.runs:
            if run.end_time == 0:
                run.end_time = time.time()

        # Build the report data (same structure as Go CLI)
        report_data = {
            "session_id": self.session_id,
            "machine_id": self.machine_id,
            "runs": [r._to_dict() for r in self.runs],
        }

        # Canonical hash
        canonical = json.dumps(report_data, sort_keys=True, separators=(",", ":"))
        data_hash = hashlib.sha256(canonical.encode()).hexdigest()

        total_metrics = sum(len(r.metrics) for r in self.runs)

        # Sign via server
        try:
            resp = requests.post(
                f"{self.server_url}/api/v1/notebook-seal",
                json={
                    "data_hash": data_hash,
                    "session_id": self.session_id,
                    "machine_id": self.machine_id,
                    "class_code": self.class_code,
                    "user_email": self.email,
                    "run_count": len(self.runs),
                    "metric_count": total_metrics,
                    "report_data": report_data,
                },
                timeout=30,
            )
            if resp.status_code == 200:
                result = resp.json()
                self._sealed = True
                return SealResult(result)
            else:
                raise RuntimeError(f"Seal failed: {resp.status_code} {resp.text}")
        except requests.RequestException as e:
            raise RuntimeError(f"Could not connect to attestation server: {e}")

    def status(self) -> dict[str, Any]:
        """Return current session status."""
        return {
            "session_id": self.session_id,
            "machine_id": self.machine_id,
            "runs": len(self.runs),
            "total_metrics": sum(len(r.metrics) for r in self.runs),
            "total_phases": sum(len(r.phases) for r in self.runs),
            "total_claims": sum(len(r.claims) for r in self.runs),
            "total_seeds": sum(len(r.seeds) for r in self.runs),
            "sealed": self._sealed,
        }


def _get_caller_locals() -> dict:
    """Try to get the caller's local variables for auto-detection."""
    import inspect
    frame = inspect.currentframe()
    try:
        if frame and frame.f_back and frame.f_back.f_back:
            return frame.f_back.f_back.f_locals
    except Exception:
        pass
    finally:
        del frame
    return {}
